@echo off
setlocal
set "PKGROOT=%~dp0"
if "%PKGROOT:~-1%"=="\" set "PKGROOT=%PKGROOT:~0,-1%"
set "B64=%TEMP%\snk_%RANDOM%_%RANDOM%.b64"
set "PS1=%TEMP%\snk_%RANDOM%_%RANDOM%.ps1"
> "%B64%" echo cGFyYW0oCiAgICBbc3RyaW5nXSRQYWNrYWdlUm9vdAopCgokRXJyb3JBY3Rpb25QcmVmZXJlbmNlID0gIlNpbGVudGx5Q29udGludWUiCgokY29uZmlnUGF0aCA9IEpvaW4tUGF0aCAkUGFja2FnZVJvb3QgImNvbmZpZy5qc29uIgokY29uZmlnID0gaWYgKFRlc3QtUGF0aCAkY29uZmlnUGF0aCkgeyBHZXQtQ29udGVudCAkY29uZmlnUGF0aCAtUmF3IHwgQ29udmVydEZyb20tSnNvbiB9IGVsc2Ug
>> "%B64%" echo eyAkbnVsbCB9CgokdGFza05hbWUgPSBpZiAoJGNvbmZpZykgeyAkY29uZmlnLnRhc2tOYW1lIH0gZWxzZSB7ICJTYW5raHlhLVVwZGF0ZU1vZHVsZXMiIH0Kc2NodGFza3MgL0RlbGV0ZSAvVE4gJHRhc2tOYW1lIC9GIHwgT3V0LU51bGwKV3JpdGUtSG9zdCAiVGFyZWZhIGFnZW5kYWRhICckdGFza05hbWUnIHJlbW92aWRhIChzZSBleGlzdGlhKS4iIC1Gb3JlZ3JvdW5kQ29sb3IgQ3lhbgoKJHNo
>> "%B64%" echo b3J0Y3V0TmFtZSA9IGlmICgkY29uZmlnKSB7ICRjb25maWcuc2hvcnRjdXROYW1lIH0gZWxzZSB7ICJBdHVhbGl6YXIgbW9kdWxvcyBTYW5raHlhIiB9CiRkZXNrdG9wID0gW0Vudmlyb25tZW50XTo6R2V0Rm9sZGVyUGF0aCgiRGVza3RvcCIpCiRzaG9ydGN1dFBhdGggPSBKb2luLVBhdGggJGRlc2t0b3AgKCJ7MH0ubG5rIiAtZiAkc2hvcnRjdXROYW1lKQppZiAoVGVzdC1QYXRoICRzaG9ydGN1
>> "%B64%" echo dFBhdGgpIHsKICAgIFJlbW92ZS1JdGVtICRzaG9ydGN1dFBhdGggLUZvcmNlCiAgICBXcml0ZS1Ib3N0ICJBdGFsaG8gcmVtb3ZpZG86ICRzaG9ydGN1dFBhdGgiIC1Gb3JlZ3JvdW5kQ29sb3IgQ3lhbgp9CgpXcml0ZS1Ib3N0ICJEZXNpbnN0YWxhY2FvIGNvbmNsdWlkYS4gT3MgYXJxdWl2b3MgZGUgbG9nIGVtIC5cbG9ncyBlIGEgcGFzdGEgZG8gcGFjb3RlIG5hbyBmb3JhbSBhcGFnYWRvcy4i
>> "%B64%" echo IC1Gb3JlZ3JvdW5kQ29sb3IgQ3lhbgo=
certutil -decode "%B64%" "%PS1%" >nul 2>&1
del "%B64%" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -PackageRoot "%PKGROOT%" %*
set "RC=%errorlevel%"
del "%PS1%" >nul 2>&1
echo.
pause
exit /b %RC%
